package com.example.nexoworxcrmapp.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.nexoworxcrmapp.data.local.dao.LeadDao
import com.example.nexoworxcrmapp.data.local.dao.PendingOperationDao
import com.example.nexoworxcrmapp.data.local.entity.LeadEntity
import com.example.nexoworxcrmapp.data.local.entity.PendingOperationEntity

@Database(
    entities = [LeadEntity::class, PendingOperationEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun leadDao(): LeadDao
    abstract fun pendingOperationDao(): PendingOperationDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "nexoworx.db",
                ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
            }
    }
}