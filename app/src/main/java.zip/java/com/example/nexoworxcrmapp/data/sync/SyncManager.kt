package com.example.nexoworxcrmapp.data.sync

import com.example.nexoworxcrmapp.data.lead.LeadRepository
import com.example.nexoworxcrmapp.data.local.dao.PendingOperationDao
import com.example.nexoworxcrmapp.data.local.entity.OperationType

class SyncManager(
    private val leadRepository: LeadRepository,
    private val pendingOpDao: PendingOperationDao,
) {
    private val maxRetries = 5

    suspend fun sync() {
        pushPending()
        leadRepository.pullFromServer()
    }

    private suspend fun pushPending() {
        val ops = pendingOpDao.getAllOrdered()
        for (op in ops) {
            if (op.retryCount >= maxRetries) continue // parked — surface in a "sync issues" list later

            val succeeded = when (op.entityType to op.operationType) {
                "LEAD" to OperationType.CREATE -> leadRepository.pushCreate(op)
                "LEAD" to OperationType.UPDATE -> leadRepository.pushUpdate(op)
                "LEAD" to OperationType.DELETE -> leadRepository.pushDelete(op)
                else -> false
            }

            if (succeeded) pendingOpDao.delete(op.opId)
            else pendingOpDao.markFailed(op.opId, "sync failed")
        }
    }
}